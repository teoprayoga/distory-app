import './styles/main.css';

import { AuthUtils } from './utils/auth.js';
import PushNotification from './utils/push-notification.js';
import LoginView from './views/login-view.js';
import RegisterView from './views/register-view.js';
import HomeView from './views/home-view.js';
import AddStoryView from './views/add-story-view.js';
import BookmarkView from './views/bookmark-view.js';
import LoginPresenter from './presenters/login-presenter.js';
import RegisterPresenter from './presenters/register-presenter.js';
import HomePresenter from './presenters/home-presenter.js';
import AddStoryPresenter from './presenters/add-story-presenter.js';
import BookmarkPresenter from './presenters/bookmark-presenter.js';

// Fix leaflet default icon for Vite
import L from 'leaflet';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: markerIcon,
  iconRetinaUrl: markerIcon2x,
  shadowUrl: markerShadow,
});

// ==============================
// Service Worker Registration
// ==============================
async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    console.log('SW registered:', reg.scope);
  } catch (err) {
    console.warn('SW registration failed:', err);
  }
}

registerServiceWorker();

// ==============================
// Router
// ==============================
class Router {
  constructor() {
    this._currentView = null;
    this._routes = {
      '/': () => this._loadHome(),
      '/login': () => this._loadLogin(),
      '/register': () => this._loadRegister(),
      '/add-story': () => this._loadAddStory(),
      '/bookmarks': () => this._loadBookmarks(),
    };
    window.addEventListener('hashchange', () => this._handleRoute());
    this.updateNav();
  }

  start() {
    this._handleRoute();
  }

  navigate(path) {
    window.location.hash = `#${path}`;
  }

  updateNav() {
    const isLoggedIn = AuthUtils.isLoggedIn();
    const navAdd = document.getElementById('nav-add');
    const navBookmarks = document.getElementById('nav-bookmarks');
    const navLogin = document.getElementById('nav-login');
    const navRegister = document.getElementById('nav-register');
    const navLogout = document.getElementById('nav-logout');
    const pushBtn = document.getElementById('push-toggle-btn');

    if (isLoggedIn) {
      if (navAdd) navAdd.style.display = 'list-item';
      if (navBookmarks) navBookmarks.style.display = 'list-item';
      if (navLogin) navLogin.style.display = 'none';
      if (navRegister) navRegister.style.display = 'none';
      if (navLogout) navLogout.style.display = 'list-item';
      if (pushBtn) pushBtn.style.display = 'flex';
      updatePushToggleState();
    } else {
      if (navAdd) navAdd.style.display = 'none';
      if (navBookmarks) navBookmarks.style.display = 'none';
      if (navLogin) navLogin.style.display = 'list-item';
      if (navRegister) navRegister.style.display = 'list-item';
      if (navLogout) navLogout.style.display = 'none';
      if (pushBtn) pushBtn.style.display = 'none';
    }
  }

  _handleRoute() {
    const hash = window.location.hash || '#/';
    const path = hash.replace('#', '') || '/';

    // Cleanup previous view
    if (this._currentView) {
      if (typeof this._currentView.destroy === 'function') this._currentView.destroy();
      if (typeof this._currentView.destroyMap === 'function') this._currentView.destroyMap();
    }

    this._updateActiveNavLink(path);

    const routeHandler = this._routes[path] || this._routes['/'];
    this._navigate(routeHandler);
  }

  async _navigate(routeHandler) {
    const container = document.getElementById('page-container');
    if (!container) return;

    // Use View Transition API if available (custom transition)
    if (document.startViewTransition) {
      await document.startViewTransition(async () => {
        container.innerHTML = '';
        await routeHandler();
        this._focusMainContent();
      }).ready;
    } else {
      // CSS fallback animation
      container.classList.add('page-exit');
      await new Promise(r => setTimeout(r, 180));
      container.innerHTML = '';
      container.classList.remove('page-exit');
      await routeHandler();
      container.classList.add('page-enter');
      setTimeout(() => container.classList.remove('page-enter'), 350);
      this._focusMainContent();
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  _focusMainContent() {
    const main = document.getElementById('main-content');
    if (main) {
      main.setAttribute('tabindex', '-1');
      main.focus({ preventScroll: true });
    }
  }

  _updateActiveNavLink(path) {
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.remove('active');
      link.removeAttribute('aria-current');
    });
    const target = document.querySelector(`.nav-link[href="#${path}"]`);
    if (target) {
      target.classList.add('active');
      target.setAttribute('aria-current', 'page');
    }
  }

  async _loadHome() {
    const view = new HomeView();
    this._currentView = view;
    const container = document.getElementById('page-container');
    container.innerHTML = view.render();
    view.afterRender();
    const presenter = new HomePresenter(view);
    if (AuthUtils.isLoggedIn()) {
      await presenter.loadStories();
    } else {
      view.showError('Silakan <a href="#/login">masuk</a> untuk melihat cerita terbaru.');
    }
  }

  _loadLogin() {
    if (AuthUtils.isLoggedIn()) { this.navigate('/'); return; }
    const view = new LoginView();
    this._currentView = view;
    const container = document.getElementById('page-container');
    container.innerHTML = view.render();
    view.afterRender();
    new LoginPresenter(view, this);
  }

  _loadRegister() {
    if (AuthUtils.isLoggedIn()) { this.navigate('/'); return; }
    const view = new RegisterView();
    this._currentView = view;
    const container = document.getElementById('page-container');
    container.innerHTML = view.render();
    view.afterRender();
    new RegisterPresenter(view, this);
  }

  _loadAddStory() {
    const view = new AddStoryView();
    this._currentView = view;
    const container = document.getElementById('page-container');
    container.innerHTML = view.render();
    view.afterRender();
    new AddStoryPresenter(view, this);
  }

  _loadBookmarks() {
    const view = new BookmarkView();
    this._currentView = view;
    const container = document.getElementById('page-container');
    container.innerHTML = view.render();
    view.afterRender();
    new BookmarkPresenter(view);
  }
}

// ==============================
// Push Notification Toggle
// ==============================
async function updatePushToggleState() {
  if (!PushNotification.isSupported()) return;
  const btn = document.getElementById('push-toggle-btn');
  const icon = document.getElementById('push-icon');
  if (!btn || !icon) return;

  try {
    const subscribed = await PushNotification.isSubscribed();
    icon.textContent = subscribed ? '🔔' : '🔕';
    btn.title = subscribed ? 'Notifikasi aktif — klik untuk nonaktifkan' : 'Aktifkan notifikasi push';
    btn.setAttribute('aria-label', subscribed ? 'Nonaktifkan notifikasi push' : 'Aktifkan notifikasi push');
    btn.dataset.subscribed = subscribed ? 'true' : 'false';
  } catch (e) {
    console.warn('Error checking push state:', e);
  }
}

document.getElementById('push-toggle-btn')?.addEventListener('click', async () => {
  if (!PushNotification.isSupported()) {
    alert('Browser Anda tidak mendukung push notification.');
    return;
  }
  if (!AuthUtils.isLoggedIn()) {
    alert('Silakan masuk terlebih dahulu untuk mengaktifkan notifikasi.');
    return;
  }

  const btn = document.getElementById('push-toggle-btn');
  const subscribed = btn?.dataset.subscribed === 'true';

  try {
    btn.disabled = true;
    if (subscribed) {
      await PushNotification.unsubscribe();
      showToastMessage('Notifikasi push dinonaktifkan.');
    } else {
      await PushNotification.subscribe();
      showToastMessage('Notifikasi push diaktifkan! 🔔');
    }
    await updatePushToggleState();
  } catch (err) {
    alert('Gagal mengubah status notifikasi: ' + err.message);
  } finally {
    if (btn) btn.disabled = false;
  }
});

function showToastMessage(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
    background: #1e293b; color: white; padding: 12px 24px;
    border-radius: 8px; z-index: 9999; font-size: 14px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ==============================
// PWA Install Prompt
// ==============================
let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  const installBtn = document.getElementById('install-btn');
  if (installBtn) installBtn.style.display = 'flex';
});

document.getElementById('install-btn')?.addEventListener('click', async () => {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  const { outcome } = await deferredInstallPrompt.userChoice;
  if (outcome === 'accepted') {
    document.getElementById('install-btn').style.display = 'none';
  }
  deferredInstallPrompt = null;
});

window.addEventListener('appinstalled', () => {
  const installBtn = document.getElementById('install-btn');
  if (installBtn) installBtn.style.display = 'none';
  deferredInstallPrompt = null;
  showToastMessage('DiStory berhasil dipasang! 🎉');
});

// ==============================
// Init App
// ==============================
const router = new Router();

// Hamburger menu
const hamburger = document.getElementById('hamburger');
const mainNav = document.getElementById('main-nav');

hamburger?.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  hamburger.setAttribute('aria-expanded', String(isOpen));
});

mainNav?.addEventListener('click', (e) => {
  if (e.target.matches('.nav-link, .nav-btn-logout')) {
    mainNav.classList.remove('open');
    hamburger?.setAttribute('aria-expanded', 'false');
  }
});

document.addEventListener('click', (e) => {
  if (!hamburger?.contains(e.target) && !mainNav?.contains(e.target)) {
    mainNav?.classList.remove('open');
    hamburger?.setAttribute('aria-expanded', 'false');
  }
});

// Keyboard: close menu on Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    mainNav?.classList.remove('open');
    hamburger?.setAttribute('aria-expanded', 'false');
  }
});

// Logout
document.getElementById('logout-btn')?.addEventListener('click', () => {
  // Try to unsubscribe push on logout
  PushNotification.unsubscribe().catch(() => {});
  AuthUtils.logout();
  router.updateNav();
  router.navigate('/login');
});

// Start
router.start();
