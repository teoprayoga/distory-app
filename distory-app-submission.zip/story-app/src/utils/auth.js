const AUTH_KEY = 'distory_auth';

export const AuthUtils = {
  saveUser(loginResult) {
    localStorage.setItem(AUTH_KEY, JSON.stringify(loginResult));
  },

  getUser() {
    try {
      const data = localStorage.getItem(AUTH_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  getToken() {
    const user = this.getUser();
    return user ? user.token : null;
  },

  isLoggedIn() {
    return !!this.getToken();
  },

  logout() {
    localStorage.removeItem(AUTH_KEY);
  },
};
