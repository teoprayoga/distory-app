import StoryAPI from '../api/story-api.js';
import { AuthUtils } from './auth.js';

// VAPID Public Key from story-api.dicoding.dev
const VAPID_PUBLIC_KEY = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

const PushNotification = {
  isSupported() {
    return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  },

  async getRegistration() {
    if (!('serviceWorker' in navigator)) return null;
    return navigator.serviceWorker.ready;
  },

  async getSubscription() {
    const reg = await this.getRegistration();
    if (!reg) return null;
    return reg.pushManager.getSubscription();
  },

  async isSubscribed() {
    const sub = await this.getSubscription();
    return !!sub;
  },

  async subscribe() {
    if (!this.isSupported()) throw new Error('Push notification tidak didukung browser ini.');

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') throw new Error('Izin notifikasi ditolak.');

    const reg = await this.getRegistration();
    if (!reg) throw new Error('Service Worker belum terdaftar.');

    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
    });

    // Send subscription to server
    const token = AuthUtils.getToken();
    if (token) {
      const subJson = sub.toJSON();
      await StoryAPI.subscribePush(token, {
        endpoint: sub.endpoint,
        keys: {
          p256dh: subJson.keys.p256dh,
          auth: subJson.keys.auth,
        },
      });
    }

    return sub;
  },

  async unsubscribe() {
    const sub = await this.getSubscription();
    if (!sub) return;

    const token = AuthUtils.getToken();
    if (token) {
      try {
        await StoryAPI.unsubscribePush(token, { endpoint: sub.endpoint });
      } catch (e) {
        console.warn('Failed to unsubscribe from server:', e);
      }
    }

    await sub.unsubscribe();
  },
};

export default PushNotification;
