import StoryAPI from '../api/story-api.js';
import { AuthUtils } from '../utils/auth.js';
import { showToast } from '../utils/toast.js';

export default class AddStoryPresenter {
  constructor(view, router) {
    this._view = view;
    this._router = router;
    view.setPresenter(this);
  }

  async onSubmit({ description, photo, lat, lon }) {
    this._view.showLoading();

    try {
      const token = AuthUtils.getToken();
      if (token) {
        await StoryAPI.addStory(token, { description, photo, lat, lon });
      } else {
        await StoryAPI.addStoryGuest({ description, photo, lat, lon });
      }

      this._view.showSuccess('Cerita berhasil dikirim! 🎉 Kamu akan diarahkan ke beranda.');
      showToast('Cerita berhasil dikirim!', 'success');
      setTimeout(() => this._router.navigate('/'), 2000);
    } catch (err) {
      this._view.hideLoading();
      this._view.showError(err.message || 'Gagal mengirim cerita. Coba lagi.');
      showToast('Gagal mengirim cerita: ' + err.message, 'error');
    }
  }
}
