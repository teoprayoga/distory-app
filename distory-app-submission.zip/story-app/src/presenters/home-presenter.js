import StoryAPI from '../api/story-api.js';
import { AuthUtils } from '../utils/auth.js';

export default class HomePresenter {
  constructor(view) {
    this._view = view;
    view.setPresenter(this);
  }

  isLoggedIn() {
    return AuthUtils.isLoggedIn();
  }

  async loadStories() {
    this._view.showLoading();
    const token = AuthUtils.getToken();

    try {
      if (!token) {
        this._view.showError('Silakan masuk terlebih dahulu untuk melihat cerita.');
        return;
      }
      const data = await StoryAPI.getStories(token, { location: 1, size: 30 });
      this._view.showStories(data.listStory || []);
    } catch (err) {
      this._view.showError(err.message || 'Gagal memuat cerita. Coba lagi nanti.');
    }
  }
}
