import StoryAPI from '../api/story-api.js';
import { AuthUtils } from '../utils/auth.js';

export default class LoginPresenter {
  constructor(view, router) {
    this._view = view;
    this._router = router;
    view.setPresenter(this);
  }

  async onLogin({ email, password }) {
    this._view.showLoading();
    this._view.clearError?.();

    try {
      const data = await StoryAPI.login({ email, password });
      AuthUtils.saveUser(data.loginResult);
      this._router.updateNav();
      this._router.navigate('/');
    } catch (err) {
      this._view.hideLoading();
      this._view.showError(err.message || 'Login gagal. Periksa kembali email dan password.');
    }
  }
}
