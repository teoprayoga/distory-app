import IDB from '../utils/idb.js';

export default class BookmarkPresenter {
  constructor(view) {
    this._view = view;
    view.setPresenter(this);
  }

  async loadBookmarks() {
    this._view.showLoading();
    try {
      const bookmarks = await IDB.getAllBookmarks();
      this._view.showBookmarks(bookmarks);
    } catch (err) {
      this._view.showError(err.message || 'Gagal memuat bookmark.');
    }
  }

  async searchBookmarks(query) {
    try {
      const bookmarks = await IDB.searchBookmarks(query);
      this._view.showBookmarks(bookmarks);
    } catch (err) {
      this._view.showError(err.message || 'Gagal mencari bookmark.');
    }
  }

  async deleteBookmark(id) {
    try {
      await IDB.deleteBookmark(id);
      await this.loadBookmarks();
    } catch (err) {
      this._view.showError(err.message || 'Gagal menghapus bookmark.');
    }
  }

  async clearAll() {
    try {
      await IDB.clearAllBookmarks();
      await this.loadBookmarks();
    } catch (err) {
      this._view.showError(err.message || 'Gagal menghapus semua bookmark.');
    }
  }
}
