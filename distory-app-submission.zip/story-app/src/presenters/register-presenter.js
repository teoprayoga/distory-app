import StoryAPI from '../api/story-api.js';

export default class RegisterPresenter {
  constructor(view, router) {
    this._view = view;
    this._router = router;
    view.setPresenter(this);
  }

  async onRegister({ name, email, password }) {
    this._view.showLoading();

    try {
      await StoryAPI.register({ name, email, password });
      this._view.showSuccess('Pendaftaran berhasil! Silakan masuk dengan akun Anda.');
      setTimeout(() => this._router.navigate('/login'), 2000);
    } catch (err) {
      this._view.hideLoading();
      this._view.showError(err.message || 'Pendaftaran gagal. Coba gunakan email lain.');
    }
  }
}
