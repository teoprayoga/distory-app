import L from 'leaflet';

export default class AddStoryView {
  constructor() {
    this._presenter = null;
    this._map = null;
    this._locationMarker = null;
    this._selectedLocation = null;
    this._photoMode = 'upload'; // 'upload' | 'camera'
    this._stream = null;
    this._photoBlob = null;
    this._photoFile = null;
  }

  setPresenter(presenter) {
    this._presenter = presenter;
  }

  render() {
    return `
      <section class="add-story-page" aria-labelledby="add-story-title">
        <header class="page-header">
          <h1 class="page-title" id="add-story-title">✏️ Tulis Cerita Baru</h1>
          <p class="page-subtitle">Bagikan pengalaman belajarmu kepada komunitas Dicoding</p>
        </header>

        <div id="add-story-alert" role="alert" aria-live="polite"></div>

        <form class="add-story-form" id="add-story-form" novalidate aria-label="Formulir tambah cerita">

          <!-- Photo Input -->
          <fieldset class="form-group photo-input-section">
            <legend class="form-label">
              Foto Cerita <span class="required" aria-label="wajib diisi">*</span>
            </legend>
            <p id="photo-error" class="form-error" role="alert" style="display:none">
              <span aria-hidden="true">⚠️</span>
              <span id="photo-error-text">Foto wajib disertakan</span>
            </p>

            <!-- Photo Mode Tabs -->
            <div class="photo-tabs" role="tablist" aria-label="Pilih cara menambah foto">
              <button
                type="button"
                class="photo-tab active"
                id="tab-upload"
                role="tab"
                aria-selected="true"
                aria-controls="panel-upload"
              >
                <span aria-hidden="true">📁</span> Unggah File
              </button>
              <button
                type="button"
                class="photo-tab"
                id="tab-camera"
                role="tab"
                aria-selected="false"
                aria-controls="panel-camera"
              >
                <span aria-hidden="true">📷</span> Kamera Langsung
              </button>
            </div>

            <!-- Upload Panel -->
            <div id="panel-upload" role="tabpanel" aria-labelledby="tab-upload">
              <div class="upload-area" id="upload-area" aria-label="Area unggah foto, klik atau drag & drop">
                <label for="photo-file-input" class="sr-only">Pilih file foto</label>
                <input
                  type="file"
                  id="photo-file-input"
                  name="photo"
                  accept="image/*"
                  aria-label="Pilih file foto"
                />
                <div class="upload-icon" aria-hidden="true">🖼️</div>
                <p class="upload-text">Klik atau drag & drop foto di sini</p>
                <p class="upload-hint">Format: JPG, PNG, GIF — Maks 1MB</p>
              </div>
            </div>

            <!-- Camera Panel -->
            <div id="panel-camera" role="tabpanel" aria-labelledby="tab-camera" style="display:none">
              <div class="camera-section">
                <video id="camera-preview" autoplay muted playsinline aria-label="Pratinjau kamera"></video>
                <canvas id="camera-canvas" aria-hidden="true"></canvas>
                <div class="camera-controls">
                  <button type="button" class="btn btn-primary" id="start-camera-btn">
                    <span aria-hidden="true">📷</span> Aktifkan Kamera
                  </button>
                  <button type="button" class="btn btn-secondary" id="capture-btn" style="display:none">
                    <span aria-hidden="true">📸</span> Ambil Foto
                  </button>
                  <button type="button" class="btn btn-danger btn-sm" id="stop-camera-btn" style="display:none">
                    Matikan Kamera
                  </button>
                </div>
              </div>
            </div>

            <!-- Photo Preview -->
            <div id="photo-preview-container" style="display:none" aria-live="polite">
              <img id="photo-preview" src="" alt="Pratinjau foto yang dipilih" class="photo-preview" />
              <button type="button" class="photo-preview-remove" id="remove-photo-btn" aria-label="Hapus foto">✕</button>
            </div>
          </fieldset>

          <!-- Description -->
          <div class="form-group">
            <label class="form-label" for="story-description">
              Deskripsi Cerita <span class="required" aria-label="wajib diisi">*</span>
            </label>
            <textarea
              id="story-description"
              name="description"
              class="form-textarea"
              placeholder="Ceritakan pengalaman belajarmu..."
              rows="5"
              required
              aria-required="true"
              aria-describedby="desc-error"
              maxlength="1000"
            ></textarea>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
              <p class="form-error" id="desc-error" role="alert" style="display:none">
                <span aria-hidden="true">⚠️</span>
                <span id="desc-error-text"></span>
              </p>
              <small id="char-count" style="color:var(--text-muted); margin-left:auto;">0/1000</small>
            </div>
          </div>

          <!-- Location Map -->
          <fieldset class="form-group">
            <legend class="form-label">Lokasi (Opsional)</legend>
            <p style="font-size:0.875rem; color:var(--text-muted); margin-bottom:10px;">
              Klik pada peta untuk memilih lokasi ceritamu
            </p>
            <div
              id="location-map"
              role="region"
              aria-label="Peta pemilihan lokasi, klik untuk memilih"
              tabindex="0"
            ></div>
            <div class="location-info" aria-live="polite">
              <div class="location-field">
                <label class="form-label" for="lat-input" style="font-size:0.8rem;">Latitude</label>
                <input
                  type="number"
                  id="lat-input"
                  class="form-input"
                  placeholder="Klik peta"
                  step="any"
                  readonly
                  aria-label="Nilai latitude lokasi"
                />
              </div>
              <div class="location-field">
                <label class="form-label" for="lon-input" style="font-size:0.8rem;">Longitude</label>
                <input
                  type="number"
                  id="lon-input"
                  class="form-input"
                  placeholder="Klik peta"
                  step="any"
                  readonly
                  aria-label="Nilai longitude lokasi"
                />
              </div>
              <div style="display:flex; align-items:flex-end; padding-bottom:2px;">
                <button type="button" class="btn btn-secondary btn-sm" id="clear-location-btn" aria-label="Hapus lokasi yang dipilih">
                  Hapus Lokasi
                </button>
              </div>
            </div>
          </fieldset>

          <!-- Submit -->
          <div style="display:flex; gap:12px; margin-top:8px; flex-wrap:wrap;">
            <button type="submit" class="btn btn-primary" id="submit-story-btn">
              <span id="submit-btn-text">🚀 Kirim Cerita</span>
              <span id="submit-btn-spinner" style="display:none" aria-hidden="true">⏳</span>
            </button>
            <a href="#/" class="btn btn-secondary">Batal</a>
          </div>
        </form>
      </section>
    `;
  }

  afterRender() {
    this._initLocationMap();
    this._bindPhotoEvents();
    this._bindFormEvents();
  }

  _initLocationMap() {
    const mapEl = document.getElementById('location-map');
    if (!mapEl) return;

    this._map = L.map('location-map').setView([-2.5, 118], 5);

    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19,
    });

    const satelliteLayer = L.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      {
        attribution: '© Esri',
        maxZoom: 19,
      }
    );

    osmLayer.addTo(this._map);
    L.control.layers({ '🗺️ Peta Jalan': osmLayer, '🛰️ Satelit': satelliteLayer }, null).addTo(this._map);

    this._map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      this._setLocation(lat, lng);
    });

    document.getElementById('clear-location-btn')?.addEventListener('click', () => {
      this._clearLocation();
    });
  }

  _setLocation(lat, lng) {
    this._selectedLocation = { lat, lon: lng };

    if (this._locationMarker) {
      this._locationMarker.setLatLng([lat, lng]);
    } else {
      this._locationMarker = L.marker([lat, lng], {
        icon: L.divIcon({
          html: '<div style="background:#4f46e5;color:#fff;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:bold;white-space:nowrap;">📍 Lokasi dipilih</div>',
          className: '',
          iconAnchor: [50, 20],
        }),
      }).addTo(this._map);
    }

    const latInput = document.getElementById('lat-input');
    const lonInput = document.getElementById('lon-input');
    if (latInput) latInput.value = lat.toFixed(6);
    if (lonInput) lonInput.value = lng.toFixed(6);
  }

  _clearLocation() {
    this._selectedLocation = null;
    if (this._locationMarker) {
      this._locationMarker.remove();
      this._locationMarker = null;
    }
    const latInput = document.getElementById('lat-input');
    const lonInput = document.getElementById('lon-input');
    if (latInput) latInput.value = '';
    if (lonInput) lonInput.value = '';
  }

  _bindPhotoEvents() {
    // Tab switching
    const tabUpload = document.getElementById('tab-upload');
    const tabCamera = document.getElementById('tab-camera');
    const panelUpload = document.getElementById('panel-upload');
    const panelCamera = document.getElementById('panel-camera');

    tabUpload?.addEventListener('click', () => {
      this._stopCamera();
      this._photoMode = 'upload';
      tabUpload.classList.add('active'); tabUpload.setAttribute('aria-selected', 'true');
      tabCamera.classList.remove('active'); tabCamera.setAttribute('aria-selected', 'false');
      panelUpload.style.display = 'block';
      panelCamera.style.display = 'none';
    });

    tabCamera?.addEventListener('click', () => {
      this._photoMode = 'camera';
      tabCamera.classList.add('active'); tabCamera.setAttribute('aria-selected', 'true');
      tabUpload.classList.remove('active'); tabUpload.setAttribute('aria-selected', 'false');
      panelCamera.style.display = 'block';
      panelUpload.style.display = 'none';
    });

    // File upload
    const fileInput = document.getElementById('photo-file-input');
    const uploadArea = document.getElementById('upload-area');

    fileInput?.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) this._handleFileSelected(file);
    });

    uploadArea?.addEventListener('dragover', (e) => {
      e.preventDefault();
      uploadArea.classList.add('drag-over');
    });
    uploadArea?.addEventListener('dragleave', () => uploadArea.classList.remove('drag-over'));
    uploadArea?.addEventListener('drop', (e) => {
      e.preventDefault();
      uploadArea.classList.remove('drag-over');
      const file = e.dataTransfer.files[0];
      if (file) this._handleFileSelected(file);
    });

    // Camera controls
    document.getElementById('start-camera-btn')?.addEventListener('click', () => this._startCamera());
    document.getElementById('capture-btn')?.addEventListener('click', () => this._capturePhoto());
    document.getElementById('stop-camera-btn')?.addEventListener('click', () => this._stopCamera());

    // Remove photo
    document.getElementById('remove-photo-btn')?.addEventListener('click', () => this._removePhoto());
  }

  _handleFileSelected(file) {
    if (!file.type.startsWith('image/')) {
      this._showPhotoError('File harus berupa gambar (JPG, PNG, dll)');
      return;
    }
    if (file.size > 1024 * 1024) {
      this._showPhotoError('Ukuran file maksimal 1MB');
      return;
    }
    this._photoFile = file;
    this._photoBlob = null;
    this._showPhotoPreview(URL.createObjectURL(file));
    this._clearPhotoError();
  }

  async _startCamera() {
    try {
      this._stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      const video = document.getElementById('camera-preview');
      if (video) {
        video.srcObject = this._stream;
        video.style.display = 'block';
      }
      document.getElementById('start-camera-btn').style.display = 'none';
      document.getElementById('capture-btn').style.display = 'inline-flex';
      document.getElementById('stop-camera-btn').style.display = 'inline-flex';
    } catch (err) {
      this._showAlert('Tidak dapat mengakses kamera: ' + err.message, 'error');
    }
  }

  _capturePhoto() {
    const video = document.getElementById('camera-preview');
    const canvas = document.getElementById('camera-canvas');
    if (!video || !canvas) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    canvas.toBlob((blob) => {
      this._photoBlob = blob;
      this._photoFile = null;
      this._showPhotoPreview(URL.createObjectURL(blob));
      this._clearPhotoError();
      this._stopCamera();
    }, 'image/jpeg', 0.85);
  }

  _stopCamera() {
    if (this._stream) {
      this._stream.getTracks().forEach(t => t.stop());
      this._stream = null;
    }
    const video = document.getElementById('camera-preview');
    if (video) { video.srcObject = null; video.style.display = 'none'; }
    const startBtn = document.getElementById('start-camera-btn');
    const captureBtn = document.getElementById('capture-btn');
    const stopBtn = document.getElementById('stop-camera-btn');
    if (startBtn) startBtn.style.display = 'inline-flex';
    if (captureBtn) captureBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'none';
  }

  _showPhotoPreview(src) {
    const container = document.getElementById('photo-preview-container');
    const img = document.getElementById('photo-preview');
    if (container) container.style.display = 'block';
    if (img) img.src = src;
  }

  _removePhoto() {
    this._photoFile = null;
    this._photoBlob = null;
    const container = document.getElementById('photo-preview-container');
    const fileInput = document.getElementById('photo-file-input');
    if (container) container.style.display = 'none';
    if (fileInput) fileInput.value = '';
  }

  _showPhotoError(msg) {
    const el = document.getElementById('photo-error');
    const text = document.getElementById('photo-error-text');
    if (el) el.style.display = 'flex';
    if (text) text.textContent = msg;
  }

  _clearPhotoError() {
    const el = document.getElementById('photo-error');
    if (el) el.style.display = 'none';
  }

  _bindFormEvents() {
    const descInput = document.getElementById('story-description');
    const charCount = document.getElementById('char-count');

    descInput?.addEventListener('input', () => {
      const len = descInput.value.length;
      if (charCount) charCount.textContent = `${len}/1000`;
      if (len > 0) {
        descInput.classList.remove('error');
        document.getElementById('desc-error').style.display = 'none';
      }
    });

    descInput?.addEventListener('blur', () => this._validateDescription(descInput.value));

    document.getElementById('add-story-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this._handleSubmit();
    });
  }

  _validateDescription(value) {
    if (!value || value.trim().length < 5) {
      document.getElementById('story-description').classList.add('error');
      document.getElementById('desc-error').style.display = 'flex';
      document.getElementById('desc-error-text').textContent = 'Deskripsi minimal 5 karakter';
      return false;
    }
    document.getElementById('story-description').classList.remove('error');
    document.getElementById('desc-error').style.display = 'none';
    return true;
  }

  _handleSubmit() {
    const description = document.getElementById('story-description').value.trim();
    const photo = this._photoFile || this._photoBlob;

    let valid = true;

    if (!photo) {
      this._showPhotoError('Foto wajib disertakan');
      valid = false;
    }

    if (!this._validateDescription(description)) {
      valid = false;
    }

    if (!valid) return;

    const photoFile = this._photoFile
      ? this._photoFile
      : new File([this._photoBlob], 'camera-photo.jpg', { type: 'image/jpeg' });

    this._presenter?.onSubmit({
      description,
      photo: photoFile,
      lat: this._selectedLocation?.lat,
      lon: this._selectedLocation?.lon,
    });
  }

  showLoading() {
    const btn = document.getElementById('submit-story-btn');
    const text = document.getElementById('submit-btn-text');
    const spinner = document.getElementById('submit-btn-spinner');
    if (btn) btn.disabled = true;
    if (text) text.textContent = 'Mengirim...';
    if (spinner) spinner.style.display = 'inline';
  }

  hideLoading() {
    const btn = document.getElementById('submit-story-btn');
    const text = document.getElementById('submit-btn-text');
    const spinner = document.getElementById('submit-btn-spinner');
    if (btn) btn.disabled = false;
    if (text) text.textContent = '🚀 Kirim Cerita';
    if (spinner) spinner.style.display = 'none';
  }

  _showAlert(message, type = 'info') {
    const alert = document.getElementById('add-story-alert');
    if (alert) {
      const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
      alert.innerHTML = `
        <div class="alert alert-${type}" role="alert">
          <span class="alert-icon" aria-hidden="true">${icon}</span>
          <span>${message}</span>
        </div>
      `;
    }
  }

  showSuccess(message) { this._showAlert(message, 'success'); }
  showError(message) { this._showAlert(message, 'error'); }

  destroy() {
    this._stopCamera();
    if (this._map) {
      this._map.remove();
      this._map = null;
    }
  }
}
