import { formatDateShort } from '../utils/date-formatter.js';

export default class BookmarkView {
  constructor() {
    this._presenter = null;
  }

  setPresenter(presenter) {
    this._presenter = presenter;
  }

  render() {
    return `
      <section aria-labelledby="bookmark-heading">
        <div class="home-hero" style="padding:32px 20px;">
          <h1 id="bookmark-heading">📌 Cerita Tersimpan</h1>
          <p>Kelola cerita yang telah Anda bookmark untuk dibaca nanti</p>
        </div>
        <div class="home-content">
          <div style="display:flex; gap:12px; align-items:center; margin-bottom:20px; flex-wrap:wrap;">
            <div style="flex:1; min-width:200px; position:relative;">
              <input
                type="search"
                id="bookmark-search"
                placeholder="Cari bookmark..."
                class="search-input"
                aria-label="Cari cerita tersimpan"
              />
            </div>
            <button class="btn btn-danger btn-sm" id="clear-all-btn" type="button" aria-label="Hapus semua bookmark">
              <span aria-hidden="true">🗑️</span> Hapus Semua
            </button>
          </div>
          <div id="bookmark-container" aria-live="polite" aria-label="Daftar bookmark"></div>
        </div>
      </section>
    `;
  }

  afterRender() {
    const searchInput = document.getElementById('bookmark-search');
    const clearAllBtn = document.getElementById('clear-all-btn');

    searchInput?.addEventListener('input', (e) => {
      this._presenter?.searchBookmarks(e.target.value);
    });

    clearAllBtn?.addEventListener('click', () => {
      if (confirm('Hapus semua bookmark? Tindakan ini tidak dapat dibatalkan.')) {
        this._presenter?.clearAll();
      }
    });

    this._presenter?.loadBookmarks();
  }

  showLoading() {
    const container = document.getElementById('bookmark-container');
    if (container) {
      container.innerHTML = `
        <div class="loading-container" role="status" aria-label="Memuat bookmark">
          <div class="spinner" aria-hidden="true"></div>
          <p class="loading-text">Memuat bookmark...</p>
        </div>
      `;
    }
  }

  showBookmarks(bookmarks) {
    const container = document.getElementById('bookmark-container');
    if (!container) return;

    if (!bookmarks || bookmarks.length === 0) {
      container.innerHTML = `
        <div class="empty-state" role="status">
          <div class="empty-icon" aria-hidden="true">📭</div>
          <h3>Belum Ada Bookmark</h3>
          <p>Simpan cerita menarik dengan klik tombol <strong>🔖 Simpan</strong> di kartu cerita.</p>
          <a href="#/" class="btn btn-primary" style="margin-top:16px;">Lihat Cerita</a>
        </div>
      `;
      return;
    }

    // Sort by savedAt desc
    const sorted = [...bookmarks].sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));

    container.innerHTML = `
      <p style="color:var(--text-secondary); margin-bottom:16px;">${bookmarks.length} cerita tersimpan</p>
      <div class="stories-grid" role="list">
        ${sorted.map(story => this._renderBookmarkCard(story)).join('')}
      </div>
    `;

    sorted.forEach(story => {
      const deleteBtn = document.getElementById(`delete-bookmark-${story.id}`);
      deleteBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        this._presenter?.deleteBookmark(story.id);
      });
    });
  }

  _renderBookmarkCard(story) {
    const { id, name, description, photoUrl, createdAt, lat, lon, savedAt } = story;
    const initial = name ? name.charAt(0).toUpperCase() : '?';
    const hasLocation = lat !== null && lon !== null && lat !== undefined && lon !== undefined;

    return `
      <article
        class="story-card"
        id="bookmark-card-${id}"
        role="listitem"
        tabindex="0"
        aria-label="Bookmark: Cerita dari ${name}"
      >
        <img
          src="${photoUrl || ''}"
          alt="Foto cerita dari ${name}"
          class="story-card-image"
          loading="lazy"
          onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23e2e8f0%22 width=%22100%25%22 height=%22100%25%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 fill=%22%2394a3b8%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3E📷%3C/text%3E%3C/svg%3E'"
        />
        <div class="story-card-body">
          <div class="story-card-author">
            <div class="story-card-avatar" aria-hidden="true">${initial}</div>
            <div>
              <div class="story-card-name">${this._escapeHtml(name || 'Anonim')}</div>
              <div class="story-card-date"><time datetime="${createdAt}">${formatDateShort(createdAt)}</time></div>
            </div>
          </div>
          <p class="story-card-desc">${this._escapeHtml(description || '')}</p>
          ${hasLocation ? `
            <div class="story-card-location">
              <span aria-hidden="true">📍</span>
              <span>Lat: ${Number(lat).toFixed(4)}, Lon: ${Number(lon).toFixed(4)}</span>
            </div>
          ` : ''}
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:12px; gap:8px; flex-wrap:wrap;">
            <small style="color:var(--text-secondary);">
              <span aria-hidden="true">🕐</span> Disimpan ${formatDateShort(savedAt)}
            </small>
            <button
              class="btn btn-danger btn-sm"
              id="delete-bookmark-${id}"
              type="button"
              aria-label="Hapus bookmark cerita dari ${name}"
            >
              <span aria-hidden="true">🗑️</span> Hapus
            </button>
          </div>
        </div>
      </article>
    `;
  }

  showError(message) {
    const container = document.getElementById('bookmark-container');
    if (container) {
      container.innerHTML = `
        <div class="empty-state" role="alert">
          <div class="empty-icon" aria-hidden="true">⚠️</div>
          <h3>Terjadi Kesalahan</h3>
          <p>${message}</p>
        </div>
      `;
    }
  }

  _escapeHtml(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }
}
