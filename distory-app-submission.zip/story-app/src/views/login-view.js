export default class LoginView {
  constructor() {
    this._presenter = null;
  }

  setPresenter(presenter) {
    this._presenter = presenter;
  }

  render() {
    return `
      <section class="auth-page" aria-labelledby="login-title">
        <div class="auth-card">
          <header class="auth-header">
            <div class="auth-icon" aria-hidden="true">🔐</div>
            <h1 class="auth-title" id="login-title">Masuk ke DiStory</h1>
            <p class="auth-subtitle">Bagikan ceritamu bersama komunitas Dicoding</p>
          </header>

          <div id="login-alert" role="alert" aria-live="polite"></div>

          <form id="login-form" novalidate aria-label="Formulir masuk">
            <div class="form-group">
              <label class="form-label" for="login-email">
                Email <span class="required" aria-label="wajib diisi">*</span>
              </label>
              <input
                type="email"
                id="login-email"
                name="email"
                class="form-input"
                placeholder="nama@email.com"
                autocomplete="email"
                required
                aria-required="true"
                aria-describedby="email-error"
              />
              <p class="form-error" id="email-error" role="alert" style="display:none">
                <span aria-hidden="true">⚠️</span>
                <span id="email-error-text"></span>
              </p>
            </div>

            <div class="form-group">
              <label class="form-label" for="login-password">
                Password <span class="required" aria-label="wajib diisi">*</span>
              </label>
              <input
                type="password"
                id="login-password"
                name="password"
                class="form-input"
                placeholder="Minimal 8 karakter"
                autocomplete="current-password"
                required
                aria-required="true"
                aria-describedby="password-error"
              />
              <p class="form-error" id="password-error" role="alert" style="display:none">
                <span aria-hidden="true">⚠️</span>
                <span id="password-error-text"></span>
              </p>
            </div>

            <button type="submit" class="btn btn-primary btn-block" id="login-btn">
              <span id="login-btn-text">Masuk</span>
              <span id="login-btn-spinner" style="display:none" aria-hidden="true">⏳</span>
            </button>
          </form>

          <p style="text-align:center; margin-top:20px; color:var(--text-muted); font-size:0.9rem;">
            Belum punya akun?
            <a href="#/register" style="font-weight:600;">Daftar sekarang</a>
          </p>
        </div>
      </section>
    `;
  }

  afterRender() {
    const form = document.getElementById('login-form');
    const emailInput = document.getElementById('login-email');
    const passwordInput = document.getElementById('login-password');

    // Real-time validation
    emailInput.addEventListener('blur', () => this._validateEmail(emailInput.value));
    passwordInput.addEventListener('blur', () => this._validatePassword(passwordInput.value));
    emailInput.addEventListener('input', () => this._clearFieldError('email'));
    passwordInput.addEventListener('input', () => this._clearFieldError('password'));

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = emailInput.value.trim();
      const password = passwordInput.value;

      const emailValid = this._validateEmail(email);
      const passValid = this._validatePassword(password);

      if (emailValid && passValid) {
        this._presenter?.onLogin({ email, password });
      }
    });
  }

  _validateEmail(value) {
    if (!value) {
      this._showFieldError('email', 'Email wajib diisi');
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      this._showFieldError('email', 'Format email tidak valid');
      return false;
    }
    this._clearFieldError('email');
    return true;
  }

  _validatePassword(value) {
    if (!value) {
      this._showFieldError('password', 'Password wajib diisi');
      return false;
    }
    if (value.length < 8) {
      this._showFieldError('password', 'Password minimal 8 karakter');
      return false;
    }
    this._clearFieldError('password');
    return true;
  }

  _showFieldError(field, message) {
    const input = document.getElementById(`login-${field}`);
    const errorEl = document.getElementById(`${field}-error`);
    const errorText = document.getElementById(`${field}-error-text`);
    if (input) { input.classList.add('error'); input.setAttribute('aria-invalid', 'true'); }
    if (errorEl) errorEl.style.display = 'flex';
    if (errorText) errorText.textContent = message;
  }

  _clearFieldError(field) {
    const input = document.getElementById(`login-${field}`);
    const errorEl = document.getElementById(`${field}-error`);
    if (input) { input.classList.remove('error'); input.removeAttribute('aria-invalid'); }
    if (errorEl) errorEl.style.display = 'none';
  }

  showLoading() {
    const btn = document.getElementById('login-btn');
    const btnText = document.getElementById('login-btn-text');
    const spinner = document.getElementById('login-btn-spinner');
    if (btn) btn.disabled = true;
    if (btnText) btnText.textContent = 'Memproses...';
    if (spinner) spinner.style.display = 'inline';
  }

  hideLoading() {
    const btn = document.getElementById('login-btn');
    const btnText = document.getElementById('login-btn-text');
    const spinner = document.getElementById('login-btn-spinner');
    if (btn) btn.disabled = false;
    if (btnText) btnText.textContent = 'Masuk';
    if (spinner) spinner.style.display = 'none';
  }

  showError(message) {
    const alert = document.getElementById('login-alert');
    if (alert) {
      alert.innerHTML = `
        <div class="alert alert-error" role="alert">
          <span class="alert-icon" aria-hidden="true">❌</span>
          <span>${message}</span>
        </div>
      `;
    }
  }

  clearError() {
    const alert = document.getElementById('login-alert');
    if (alert) alert.innerHTML = '';
  }
}
