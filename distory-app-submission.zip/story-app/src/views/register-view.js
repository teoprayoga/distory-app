export default class RegisterView {
  constructor() {
    this._presenter = null;
  }

  setPresenter(presenter) {
    this._presenter = presenter;
  }

  render() {
    return `
      <section class="auth-page" aria-labelledby="register-title">
        <div class="auth-card">
          <header class="auth-header">
            <div class="auth-icon" aria-hidden="true">✨</div>
            <h1 class="auth-title" id="register-title">Daftar DiStory</h1>
            <p class="auth-subtitle">Bergabung dan mulai berbagi ceritamu</p>
          </header>

          <div id="register-alert" role="alert" aria-live="polite"></div>

          <form id="register-form" novalidate aria-label="Formulir pendaftaran">
            <div class="form-group">
              <label class="form-label" for="reg-name">
                Nama Lengkap <span class="required" aria-label="wajib diisi">*</span>
              </label>
              <input
                type="text"
                id="reg-name"
                name="name"
                class="form-input"
                placeholder="Masukkan nama lengkap"
                autocomplete="name"
                required
                aria-required="true"
                aria-describedby="name-error"
              />
              <p class="form-error" id="name-error" role="alert" style="display:none">
                <span aria-hidden="true">⚠️</span>
                <span id="name-error-text"></span>
              </p>
            </div>

            <div class="form-group">
              <label class="form-label" for="reg-email">
                Email <span class="required" aria-label="wajib diisi">*</span>
              </label>
              <input
                type="email"
                id="reg-email"
                name="email"
                class="form-input"
                placeholder="nama@email.com"
                autocomplete="email"
                required
                aria-required="true"
                aria-describedby="reg-email-error"
              />
              <p class="form-error" id="reg-email-error" role="alert" style="display:none">
                <span aria-hidden="true">⚠️</span>
                <span id="reg-email-error-text"></span>
              </p>
            </div>

            <div class="form-group">
              <label class="form-label" for="reg-password">
                Password <span class="required" aria-label="wajib diisi">*</span>
              </label>
              <input
                type="password"
                id="reg-password"
                name="password"
                class="form-input"
                placeholder="Minimal 8 karakter"
                autocomplete="new-password"
                required
                aria-required="true"
                aria-describedby="reg-password-error"
              />
              <p class="form-error" id="reg-password-error" role="alert" style="display:none">
                <span aria-hidden="true">⚠️</span>
                <span id="reg-password-error-text"></span>
              </p>
            </div>

            <button type="submit" class="btn btn-primary btn-block" id="register-btn">
              <span id="register-btn-text">Daftar Sekarang</span>
              <span id="register-btn-spinner" style="display:none" aria-hidden="true">⏳</span>
            </button>
          </form>

          <p style="text-align:center; margin-top:20px; color:var(--text-muted); font-size:0.9rem;">
            Sudah punya akun?
            <a href="#/login" style="font-weight:600;">Masuk di sini</a>
          </p>
        </div>
      </section>
    `;
  }

  afterRender() {
    const form = document.getElementById('register-form');
    const nameInput = document.getElementById('reg-name');
    const emailInput = document.getElementById('reg-email');
    const passInput = document.getElementById('reg-password');

    nameInput.addEventListener('blur', () => this._validateName(nameInput.value));
    emailInput.addEventListener('blur', () => this._validateEmail(emailInput.value));
    passInput.addEventListener('blur', () => this._validatePassword(passInput.value));
    nameInput.addEventListener('input', () => this._clearFieldError('name'));
    emailInput.addEventListener('input', () => this._clearFieldError('reg-email'));
    passInput.addEventListener('input', () => this._clearFieldError('reg-password'));

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const password = passInput.value;

      const nameValid = this._validateName(name);
      const emailValid = this._validateEmail(email);
      const passValid = this._validatePassword(password);

      if (nameValid && emailValid && passValid) {
        this._presenter?.onRegister({ name, email, password });
      }
    });
  }

  _validateName(value) {
    if (!value || value.trim().length < 2) {
      this._showFieldError('name', 'Nama minimal 2 karakter');
      return false;
    }
    this._clearFieldError('name');
    return true;
  }

  _validateEmail(value) {
    if (!value) {
      this._showFieldError('reg-email', 'Email wajib diisi');
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      this._showFieldError('reg-email', 'Format email tidak valid');
      return false;
    }
    this._clearFieldError('reg-email');
    return true;
  }

  _validatePassword(value) {
    if (!value) {
      this._showFieldError('reg-password', 'Password wajib diisi');
      return false;
    }
    if (value.length < 8) {
      this._showFieldError('reg-password', 'Password minimal 8 karakter');
      return false;
    }
    this._clearFieldError('reg-password');
    return true;
  }

  _showFieldError(field, message) {
    const input = document.getElementById(`reg-${field}`) || document.getElementById(field);
    const errorEl = document.getElementById(`${field}-error`);
    const errorText = document.getElementById(`${field}-error-text`);
    if (input) { input.classList.add('error'); input.setAttribute('aria-invalid', 'true'); }
    if (errorEl) errorEl.style.display = 'flex';
    if (errorText) errorText.textContent = message;
  }

  _clearFieldError(field) {
    const input = document.getElementById(`reg-${field}`) || document.getElementById(field);
    const errorEl = document.getElementById(`${field}-error`);
    if (input) { input.classList.remove('error'); input.removeAttribute('aria-invalid'); }
    if (errorEl) errorEl.style.display = 'none';
  }

  showLoading() {
    const btn = document.getElementById('register-btn');
    const btnText = document.getElementById('register-btn-text');
    const spinner = document.getElementById('register-btn-spinner');
    if (btn) btn.disabled = true;
    if (btnText) btnText.textContent = 'Mendaftar...';
    if (spinner) spinner.style.display = 'inline';
  }

  hideLoading() {
    const btn = document.getElementById('register-btn');
    const btnText = document.getElementById('register-btn-text');
    const spinner = document.getElementById('register-btn-spinner');
    if (btn) btn.disabled = false;
    if (btnText) btnText.textContent = 'Daftar Sekarang';
    if (spinner) spinner.style.display = 'none';
  }

  showError(message) {
    const alert = document.getElementById('register-alert');
    if (alert) {
      alert.innerHTML = `
        <div class="alert alert-error" role="alert">
          <span class="alert-icon" aria-hidden="true">❌</span>
          <span>${message}</span>
        </div>
      `;
    }
  }

  showSuccess(message) {
    const alert = document.getElementById('register-alert');
    if (alert) {
      alert.innerHTML = `
        <div class="alert alert-success" role="alert">
          <span class="alert-icon" aria-hidden="true">✅</span>
          <span>${message}</span>
        </div>
      `;
    }
  }
}
