import L from 'leaflet';
import { formatDateShort } from '../utils/date-formatter.js';
import IDB from '../utils/idb.js';

export default class HomeView {
  constructor() {
    this._presenter = null;
    this._map = null;
    this._markers = [];
    this._activeMarkerId = null;
    this._bookmarkedIds = new Set();
  }

  setPresenter(presenter) {
    this._presenter = presenter;
  }

  render() {
    return `
      <section aria-labelledby="home-heading">
        <!-- Hero -->
        <div class="home-hero">
          <h1 id="home-heading">Berbagi Cerita Dicoding 📖</h1>
          <p>Temukan dan bagikan pengalaman belajarmu bersama komunitas Dicoding Indonesia</p>
          <a href="#/add-story" class="hero-cta" id="hero-cta-btn">
            <span aria-hidden="true">✏️</span> Tulis Ceritamu
          </a>
        </div>

        <div class="home-content">
          <!-- Map Section -->
          <section class="stories-section" aria-labelledby="map-title">
            <h2 class="section-title" id="map-title">
              <span aria-hidden="true">🗺️</span> Peta Cerita
            </h2>
            <div id="story-map" role="region" aria-label="Peta lokasi cerita" tabindex="0"></div>
          </section>

          <!-- Stories List Section -->
          <section aria-labelledby="stories-title">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:8px;">
              <h2 class="section-title" id="stories-title" style="margin-bottom:0;">
                <span aria-hidden="true">📚</span> Cerita Terbaru
              </h2>
              <button class="btn btn-secondary btn-sm" id="refresh-btn" aria-label="Muat ulang cerita" type="button">
                <span aria-hidden="true">🔄</span> Refresh
              </button>
            </div>
            <div id="stories-container" aria-live="polite" aria-label="Daftar cerita"></div>
          </section>
        </div>
      </section>
    `;
  }

  afterRender() {
    this._initMap();
    document.getElementById('refresh-btn')?.addEventListener('click', () => {
      this._presenter?.loadStories();
    });

    // Update hero CTA based on auth
    const heroCta = document.getElementById('hero-cta-btn');
    if (heroCta && !this._presenter?.isLoggedIn()) {
      heroCta.href = '#/login';
      heroCta.textContent = '';
      heroCta.innerHTML = '<span aria-hidden="true">🔐</span> Masuk untuk Bercerita';
    }
  }

  async _loadBookmarkState() {
    try {
      const bookmarks = await IDB.getAllBookmarks();
      this._bookmarkedIds = new Set(bookmarks.map(b => b.id));
    } catch {
      this._bookmarkedIds = new Set();
    }
  }

  _initMap() {
    const mapEl = document.getElementById('story-map');
    if (!mapEl || this._map) return;

    this._map = L.map('story-map', {
      center: [-2.5, 118],
      zoom: 5,
    });

    // Tile layers
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    });

    const satelliteLayer = L.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      {
        attribution: '© Esri — Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP',
        maxZoom: 19,
      }
    );

    const topoLayer = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenTopoMap contributors',
      maxZoom: 17,
    });

    osmLayer.addTo(this._map);

    // Layer control
    const baseLayers = {
      '🗺️ Peta Jalan': osmLayer,
      '🛰️ Satelit': satelliteLayer,
      '⛰️ Topografi': topoLayer,
    };
    L.control.layers(baseLayers, null, { position: 'topright' }).addTo(this._map);
  }

  showLoading() {
    const container = document.getElementById('stories-container');
    if (container) {
      container.innerHTML = `
        <div class="loading-container" role="status" aria-label="Memuat cerita">
          <div class="spinner" aria-hidden="true"></div>
          <p class="loading-text">Memuat cerita...</p>
        </div>
      `;
    }
  }

  async showStories(stories) {
    const container = document.getElementById('stories-container');
    if (!container) return;

    // Load bookmark state first
    await this._loadBookmarkState();

    if (!stories || stories.length === 0) {
      container.innerHTML = `
        <div class="empty-state" role="status">
          <div class="empty-icon" aria-hidden="true">📭</div>
          <h3>Belum Ada Cerita</h3>
          <p>Jadilah yang pertama berbagi ceritamu!</p>
          <a href="#/add-story" class="btn btn-primary" style="margin-top:16px;">Tulis Cerita</a>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="stories-grid" role="list">
        ${stories.map(story => this._renderStoryCard(story)).join('')}
      </div>
    `;

    // Add event listeners to cards
    stories.forEach(story => {
      const card = document.getElementById(`story-card-${story.id}`);
      if (card) {
        card.addEventListener('click', (e) => {
          if (!e.target.closest('.bookmark-btn')) {
            this._onStoryCardClick(story);
          }
        });
        card.addEventListener('keydown', (e) => {
          if ((e.key === 'Enter' || e.key === ' ') && !e.target.closest('.bookmark-btn')) {
            e.preventDefault();
            this._onStoryCardClick(story);
          }
        });
      }

      // Bookmark button listener
      const bookmarkBtn = document.getElementById(`bookmark-btn-${story.id}`);
      if (bookmarkBtn) {
        bookmarkBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          await this._toggleBookmark(story, bookmarkBtn);
        });
      }
    });

    // Update map markers
    this._updateMapMarkers(stories);
  }

  async _toggleBookmark(story, btn) {
    try {
      const isBookmarked = this._bookmarkedIds.has(story.id);
      if (isBookmarked) {
        await IDB.deleteBookmark(story.id);
        this._bookmarkedIds.delete(story.id);
        btn.innerHTML = '<span aria-hidden="true">🔖</span>';
        btn.setAttribute('aria-label', `Simpan cerita dari ${story.name}`);
        btn.title = 'Simpan ke bookmark';
        btn.classList.remove('bookmarked');
      } else {
        await IDB.addBookmark(story);
        this._bookmarkedIds.add(story.id);
        btn.innerHTML = '<span aria-hidden="true">📌</span>';
        btn.setAttribute('aria-label', `Hapus bookmark cerita dari ${story.name}`);
        btn.title = 'Hapus dari bookmark';
        btn.classList.add('bookmarked');
      }
    } catch (e) {
      console.error('Bookmark error:', e);
    }
  }

  _renderStoryCard(story) {
    const { id, name, description, photoUrl, createdAt, lat, lon } = story;
    const initial = name ? name.charAt(0).toUpperCase() : '?';
    const hasLocation = lat !== null && lon !== null && lat !== undefined && lon !== undefined;

    return `
      <article
        class="story-card"
        id="story-card-${id}"
        role="listitem"
        tabindex="0"
        aria-label="Cerita dari ${name}: ${description?.substring(0, 60) || ''}"
      >
        <img
          src="${photoUrl || ''}"
          alt="Foto cerita dari ${name}"
          class="story-card-image"
          loading="lazy"
          onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23e2e8f0%22 width=%22100%25%22 height=%22100%25%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 fill=%22%2394a3b8%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3E📷%3C/text%3E%3C/svg%3E'"
        />
        <div class="story-card-body">
          <div class="story-card-author">
            <div class="story-card-avatar" aria-hidden="true">${initial}</div>
            <div>
              <div class="story-card-name">${this._escapeHtml(name || 'Anonim')}</div>
              <div class="story-card-date"><time datetime="${createdAt}">${formatDateShort(createdAt)}</time></div>
            </div>
          </div>
          <p class="story-card-desc">${this._escapeHtml(description || '')}</p>
          ${hasLocation ? `
            <div class="story-card-location">
              <span aria-hidden="true">📍</span>
              <span>Lat: ${Number(lat).toFixed(4)}, Lon: ${Number(lon).toFixed(4)}</span>
            </div>
          ` : ''}
          <div class="story-card-actions">
            <button
              class="bookmark-btn ${this._bookmarkedIds.has(id) ? 'bookmarked' : ''}"
              id="bookmark-btn-${id}"
              type="button"
              aria-label="${this._bookmarkedIds.has(id) ? `Hapus bookmark cerita dari ${name}` : `Simpan cerita dari ${name}`}"
              title="${this._bookmarkedIds.has(id) ? 'Hapus dari bookmark' : 'Simpan ke bookmark'}"
            >
              <span aria-hidden="true">${this._bookmarkedIds.has(id) ? '📌' : '🔖'}</span>
            </button>
          </div>
        </div>
      </article>
    `;
  }

  _updateMapMarkers(stories) {
    if (!this._map) return;

    // Clear old markers
    this._markers.forEach(m => m.marker.remove());
    this._markers = [];

    const storiesWithLocation = stories.filter(
      s => s.lat !== null && s.lon !== null && s.lat !== undefined && s.lon !== undefined
    );

    const bounds = [];

    storiesWithLocation.forEach(story => {
      const { id, name, description, photoUrl, lat, lon } = story;

      // Custom icon
      const icon = L.divIcon({
        html: `<div style="
          background: var(--primary, #4f46e5);
          color: white;
          width: 32px;
          height: 32px;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          border: 3px solid white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
        "><span style="transform: rotate(45deg); font-size:14px;">📖</span></div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -36],
        className: '',
      });

      const marker = L.marker([lat, lon], { icon, title: name })
        .addTo(this._map)
        .bindPopup(`
          <div class="story-popup">
            <img src="${photoUrl || ''}" alt="Foto cerita ${name}" class="story-popup-img"
              onerror="this.style.display='none'" />
            <p class="story-popup-name">${this._escapeHtml(name || 'Anonim')}</p>
            <p class="story-popup-desc">${this._escapeHtml((description || '').substring(0, 100))}${description?.length > 100 ? '...' : ''}</p>
          </div>
        `, { maxWidth: 200 });

      marker.on('click', () => this._highlightCard(id));

      this._markers.push({ id, marker });
      bounds.push([lat, lon]);
    });

    if (bounds.length > 0) {
      this._map.fitBounds(bounds, { padding: [40, 40], maxZoom: 8 });
    }
  }

  _onStoryCardClick(story) {
    if (!story.lat || !story.lon) return;
    this._highlightCard(story.id);
    const markerData = this._markers.find(m => m.id === story.id);
    if (markerData) {
      this._map.setView([story.lat, story.lon], 12, { animate: true });
      markerData.marker.openPopup();
    }
  }

  _highlightCard(storyId) {
    // Remove previous highlight
    if (this._activeMarkerId) {
      const prev = document.getElementById(`story-card-${this._activeMarkerId}`);
      if (prev) prev.classList.remove('active');
    }
    // Add highlight
    const card = document.getElementById(`story-card-${storyId}`);
    if (card) {
      card.classList.add('active');
      card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    this._activeMarkerId = storyId;
  }

  showError(message) {
    const container = document.getElementById('stories-container');
    if (container) {
      container.innerHTML = `
        <div class="empty-state" role="alert">
          <div class="empty-icon" aria-hidden="true">⚠️</div>
          <h3>Terjadi Kesalahan</h3>
          <p>${message}</p>
          <button class="btn btn-primary" id="retry-btn" style="margin-top:16px;" type="button">Coba Lagi</button>
        </div>
      `;
      document.getElementById('retry-btn')?.addEventListener('click', () => {
        this._presenter?.loadStories();
      });
    }
  }

  destroyMap() {
    if (this._map) {
      this._map.remove();
      this._map = null;
      this._markers = [];
    }
  }

  _escapeHtml(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }
}
