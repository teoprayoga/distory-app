const BASE_URL = 'https://story-api.dicoding.dev/v1';

const StoryAPI = {
  async register({ name, email, password }) {
    const response = await fetch(`${BASE_URL}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async login({ email, password }) {
    const response = await fetch(`${BASE_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async getStories(token, { page = 1, size = 20, location = 1 } = {}) {
    const params = new URLSearchParams({ page, size, location });
    const response = await fetch(`${BASE_URL}/stories?${params}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async getStoryDetail(token, id) {
    const response = await fetch(`${BASE_URL}/stories/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async addStory(token, { description, photo, lat, lon }) {
    const formData = new FormData();
    formData.append('description', description);
    formData.append('photo', photo);
    if (lat !== undefined && lon !== undefined) {
      formData.append('lat', lat);
      formData.append('lon', lon);
    }
    const response = await fetch(`${BASE_URL}/stories`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async addStoryGuest({ description, photo, lat, lon }) {
    const formData = new FormData();
    formData.append('description', description);
    formData.append('photo', photo);
    if (lat !== undefined && lon !== undefined) {
      formData.append('lat', lat);
      formData.append('lon', lon);
    }
    const response = await fetch(`${BASE_URL}/stories/guest`, {
      method: 'POST',
      body: formData,
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async subscribePush(token, { endpoint, keys }) {
    const response = await fetch(`${BASE_URL}/notifications/subscribe`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ endpoint, keys }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },

  async unsubscribePush(token, { endpoint }) {
    const response = await fetch(`${BASE_URL}/notifications/subscribe`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ endpoint }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.message);
    return data;
  },
};

export default StoryAPI;
